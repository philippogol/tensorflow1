import React, {useEffect, useRef, useState} from 'react';
import {View, Text, Image} from 'react-native';
import * as tf from '@tensorflow/tfjs';
import {fetch, decodeJpeg} from '@tensorflow/tfjs-react-native';
const imageUri = 'https://www.la-spa.fr/app/app/uploads/2023/07/prendre-soin_duree-vie-chat.jpg'; 
const App = () => {
  const [isTfReady, setIsTfReady] = useState(false);
  const [result, setResult] = useState<{}>();
  const image = useRef(null);

  const load = async () => {
    try {
      // Load TensorFlow.js and MobileNet model
      await tf.ready();
      setIsTfReady(true);

    
      const response = await fetch(imageUri, {}, { isBinary: true });
      const imageDataArrayBuffer = await response.arrayBuffer();
      const imageData = new Uint8Array(imageDataArrayBuffer);
      
      // Decode image data to a tensor
      const imageTensor = decodeJpeg(imageData);
      console.log('\x1b[34m%s\x1b[0m', 'App.tsx:25 imageTensor', imageTensor);
      setResult(imageTensor)
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <View
      style={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white'
      }}>
      <Image
        ref={image}
        source={{uri:imageUri}}
        style={{width: 200, height: 200}}
      />
      {!isTfReady && <Text>Loading TFJS model...</Text>}
      {isTfReady && result === '' && <Text>Classifying...</Text>}
      {result !== '' && <Text>{JSON.stringify(result)}</Text>}
    </View>
  );
};

export default App;