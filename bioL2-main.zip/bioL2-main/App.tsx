import React, {useEffect, useRef, useState} from 'react';
import {View, Text, Image, Button, StyleSheet} from 'react-native';
import * as tf from '@tensorflow/tfjs';
import {fetch, decodeJpeg} from '@tensorflow/tfjs-react-native';
import * as cocoSsd from '@tensorflow-models/coco-ssd';

const imageUri = 'https://www.la-spa.fr/app/app/uploads/2023/07/prendre-soin_duree-vie-chat.jpg'; 

const App = () => {
  const [isTfReady, setIsTfReady] = useState(false);
  const [model, setModel] = useState<any>(null);
  const [result, setResult] = useState<any[]>([]);
  const image = useRef(null);

  const loadModels = async () => {
    try {
      await tf.ready();
      setIsTfReady(true);

      // Load COCO-SSD model
      const cocoModel = await cocoSsd.load();
      setModel(cocoModel);
    } catch (err) {
      console.error(err);
    }
  };

  const classifyImage = async () => {
    if (!model) {
      console.warn('Model is not loaded yet');
      return;
    }

    try {
      const response = await fetch(imageUri, {}, { isBinary: true });
      const imageDataArrayBuffer = await response.arrayBuffer();
      const imageData = new Uint8Array(imageDataArrayBuffer);
      
      // Decode image data to a tensor
      const imageTensor = decodeJpeg(imageData);
      
      // Run object detection
      const predictions = await model.detect(imageTensor);
      
      setResult(predictions);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadModels();
  }, []);

  return (
    <View style={styles.container}>
      <Image
        ref={image}
        source={{uri: imageUri}}
        style={styles.image}
      />
      {!isTfReady && <Text>Loading TensorFlow.js model...</Text>}
      {isTfReady && model === null && <Text>Loading COCO-SSD model...</Text>}
      {isTfReady && model !== null && (
        <>
          <Button title="Classify Image" onPress={classifyImage} />
          {result.length > 0 && (
            <View style={styles.results}>
              {result.map((res, index) => (
                <Text key={index}>
                  {`${res.class}: ${(res.score * 100).toFixed(2)}%`}
                </Text>
              ))}
            </View>
          )}
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  image: {
    width: 200,
    height: 200,
  },
  results: {
    marginTop: 20,
  },
});

export default App;
