import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Image } from 'react-native';
import * as tf from '@tensorflow/tfjs';
import { fetch, decodeJpeg } from '@tensorflow/tfjs-react-native';
import * as mobilenet from '@tensorflow-models/mobilenet';

const imageUri = 'https://www.la-spa.fr/app/app/uploads/2023/07/prendre-soin_duree-vie-chat.jpg'; 

const App = () => {
  const [isTfReady, setIsTfReady] = useState(false);
  const [model, setModel] = useState<mobilenet.MobileNet | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const image = useRef(null);

  const load = async () => {
    try {
      // Load TensorFlow.js and MobileNet model
      await tf.ready();
      const net = await mobilenet.load();
      setModel(net);
      setIsTfReady(true);

      const response = await fetch(imageUri, {}, { isBinary: true });
      const imageDataArrayBuffer = await response.arrayBuffer();
      const imageData = new Uint8Array(imageDataArrayBuffer);
      
      // Decode image data to a tensor
      const imageTensor = decodeJpeg(imageData);
      
      // Classify the image
      const predictions = await net.classify(imageTensor);
      setResult(JSON.stringify(predictions, null, 2));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <View
      style={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white'
      }}>
      <Image
        ref={image}
        source={{ uri: imageUri }}
        style={{ width: 200, height: 200 }}
      />
      {!isTfReady && <Text>Loading TFJS model...</Text>}
      {isTfReady && !result && <Text>Classifying...</Text>}
      {result && <Text>{result}</Text>}
    </View>
  );
};

export default App;
