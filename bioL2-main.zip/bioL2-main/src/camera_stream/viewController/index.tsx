import React, {
Dispatch,
SetStateAction,
useCallback,
useEffect,
useState,
useMemo
} from 'react';
const useCameraStreamViewController = () => {
const values = useMemo(()=>{return {
} },[])
return values;
};
export default useCameraStreamViewController;