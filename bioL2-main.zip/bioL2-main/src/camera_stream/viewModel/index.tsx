import React, {
Dispatch,
SetStateAction,
useCallback,
useEffect,
useState,
useMemo
} from 'react';
const useCameraStreamViewModels = () => {
const values = useMemo(()=>{return {
} },[])
return values;
};
export default useCameraStreamViewModels;