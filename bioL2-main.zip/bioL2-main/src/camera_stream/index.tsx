import React, { useCallback } from 'react';
import { View, StyleSheet } from 'react-native';
import { Camera } from 'expo-camera';
import { cameraWithTensors } from '@tensorflow/tfjs-react-native';

const TensorCamera = cameraWithTensors(Camera);

const MyComponent = () => {
  const handleCameraStream = useCallback((images, updatePreview, gl) => {
    const loop = async () => {
      const nextImageTensor = images.next().value;

      // Do something with tensor here

      // If autorender is false you need the following two lines.
      // updatePreview();
      // gl.endFrameEXP();

      requestAnimationFrame(loop);
    };
    loop();
  }, []);

  return (
    <View style={styles.container}>
      <TensorCamera
        // Standard Camera props
        style={styles.camera}
        type={Camera?.Constants?.Type.front}
        // Tensor related props
        resizeHeight={200}
        resizeWidth={152}
        resizeDepth={3}
        onReady={handleCameraStream}
        autorender={true} useCustomShadersToResize={false} cameraTextureWidth={0} cameraTextureHeight={0}      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  camera: {
    flex: 1,
  },
});

export default MyComponent;
